# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
import random

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

class Node: #clasa node pe care o uitlizam pentru parcurgere
    #fiecare nod are un parinte, actiune, pozitie si cost
    def __init__(self, parent, action, position, cost): #constructor
        self.parent = parent
        self.action = action
        self.position = position
        self.cost = cost
    
    ## gettere
    def getParent(self):
        return self.parent
    
    def getAction(self):
        return self.action
    
    def getPosition(self):
        return self.position
    
    def getCost(self):
        return self.cost
    
    #functia pathList primeste nodul si o lista cu ajutorul carora fomeaza lista caii
    def pathList(self, node, nodeList):
        if node.parent == None:
            return
        else:
            nodeList.append(node.action)
            self.pathList(node.parent, nodeList)

def depthFirstSearch(problem: SearchProblem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"

    #DFS expandeaza cel mai adanc nod neexpandat

    stiva = util.Stack() #frontiera: LIFO -> stiva
    firstNode = Node(None, None, problem.getStartState(), 0) #initializam primul nod cu .getStartState
    stiva.push(firstNode) #adaugam nodul in stiva

    blackNodes = [] # lista de noduri vizitate
    path = [] #calea

    while True:

        if(stiva.isEmpty()): #verificam ca stiva sa nu fie goala
            break
        
        DFSnode = stiva.pop() #extragem un nod din stiva

        if problem.isGoalState(DFSnode.position): #verificam daca nu am ajuns la final
            break

        if DFSnode not in blackNodes: #daca nodul nu a fost expandat, il expandam
            blackNodes.append(DFSnode.position)
            for succ in problem.getSuccessors(DFSnode.position): #parcurgem fiecare succesor
                if succ[0] not in blackNodes: #daca succesorul nodului DFSnode nu a fost expandat, il adaugam in stiva
                    stiva.push(Node(DFSnode, succ[1], succ[0], succ[2]))
    
    DFSnode.pathList(DFSnode,path) #formam calea
    path.reverse() #trebuie sa inversam lista ca sa iasa bine la autograder

    return path

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"

    #BFS expandeaza cel mai superficial nod neexpandat (vecinii)

    coada = util.Queue() #frontiera: FIFO -> coada
    firstNode = Node(None, None, problem.getStartState(), 0) #initializam primul nod din pozitia de start
    coada.push(firstNode) #adaugam nodul de start in coada
    
    blackNodes = [] #initializare lista de noduri vizitate
    path = [] #calea

    while True:

        if coada.isEmpty(): #conditia de oprire in care coada este goala
            break

        BFSnode = coada.pop() #extragem un nod din lista

        if problem.isGoalState(BFSnode.position): #conditia de oprire in care am ajuns la final
            break

        if BFSnode.position not in blackNodes: #daca nodul nu a fost vizitat

            blackNodes.append(BFSnode.position) #adaugam in lista de noduri vizitate

            for succ in problem.getSuccessors(BFSnode.position): #parcurgem fiecare succesor
                if succ[0] not in blackNodes: #daca succesorul nodului nu a fost vizitat
                    coada.push(Node(BFSnode, succ[1], succ[0], succ[2])) #il adaugam in coada

    BFSnode.pathList(BFSnode,path)
    path.reverse() #inversam calea

    return path


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    #are la baza parcurgearea in latime cu cost
    #deoarece fiecare cod are un cost, folosim o coada de prioritati
    coada = util.PriorityQueue() #intializam coda

    firstNode = Node(None, None, problem.getStartState(), 0) #initializam primul nod cu pozitia de start si costul 0
    coada.push(firstNode, firstNode.cost) #adaugam codul in coada
    
    blackNodes = []
    path = []
    
    while True:

        if coada.isEmpty():
            break

        nod = coada.pop()

        if problem.isGoalState(nod.position):
            break

        if nod.position not in blackNodes:
            blackNodes.append(nod.position)
            for succ in problem.getSuccessors(nod.position):
                if succ[0] not in blackNodes:
                    uniCost = nod.cost + succ[2] #noul cost
                    coada.push(Node(nod, succ[1], succ[0], uniCost), uniCost)

    nod.pathList(nod, path)
    path.reverse()

    return path

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    #identic cu UniformCostSearch, A* expandeaza dupa f(n) = g(n) + h(n) minim

    blackNodes = [] #noduri vizitate
    path = [] #calea

    coada = util.PriorityQueue() #initializam coada de prioritati

    firstNode = Node(None, None, problem.getStartState(), 0) #initializam nodul de start cu pozitia de start si cost 0
    coada.push(firstNode, firstNode.cost) #adaugam nodul in coada

    while True:

        if coada.isEmpty():
            break

        nod = coada.pop()
        blackNodes.append(nod)

        if problem.isGoalState(nod.position):
            break
        
        for succ in problem.getSuccessors(nod.position): 
            #formarea costului pentru nodul copil
            child = Node(nod, succ[1], succ[0], nod.cost + succ[2]) #formarea nodului copil cu noul cost
            g = nod.cost + succ[2] 
            h = heuristic(child.position, problem) 

            flag = True
            for nodes in blackNodes:

                if (nodes.position == child.position) and (nodes.cost <= child.cost): #daca exista un nod cu aceeasi pozitie cu succesorul si are cost mai mic
                    flag = False #nu trebuie sa punem nodul in coada
            
            if flag:
                coada.push(child, g + h)
                blackNodes.append(child)

    nod.pathList(nod, path)
    path.reverse()

    return path

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
