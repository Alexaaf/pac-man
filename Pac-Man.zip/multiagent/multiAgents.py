# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent
from pacman import GameState

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState: GameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState: GameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood().asList()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"

        #folosim un Agent Reflex bazat pe distanta Manhattan care se misca in functie de cea mai apropiata mancare si posibilele pozitii ale fantomelor

        minDistance = 999999

        #parcurgem toate punctele de mancare si luam pe rand punctele care au distanta Manhattan cea mai mica fata de pozitia noastra
        for food in newFood:
            if minDistance > manhattanDistance(newPos, food):
                minDistance = manhattanDistance(newPos, food)

        for ghost in successorGameState.getGhostPositions(): #verificam si pozitia fantomelor, iar daca o fantoma s-ar putea intersecta cu noi la urmatoarul pas, oprim miscarea pac-man-ului
            if (manhattanDistance(newPos, ghost) <= 1):
                return -1

        return successorGameState.getScore() + 1.0  / minDistance

        #util.raiseNotDefined()



def scoreEvaluationFunction(currentGameState: GameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"

        #Algoritmul Minimax functioneaza in mod recursiv. Acesta coboara pana la frunze si urca inapoi pe arbore cu valoarea minimax pentru nodul parinte al frunzelor
        #Are la baza DFS

        def minMax(gameState, agent, depth):
            
            #verificam ca starea de inceput sa nu fie finalul jocului sau daca am atins lungimea maxima de actiuni legale

            if gameState.isWin():
                return self.evaluationFunction(gameState)

            if gameState.isLose():
                return self.evaluationFunction(gameState)

            if depth == self.depth:
                return self.evaluationFunction(gameState)

            #starea de inceput
            if agent != 0:

                #nu suntem la pac-man deci coboram un nivel adica la o fantoma si nodul va lua valoarea minima dupa apelul recursiv de aflare al valorilor de pe frunze
                nextAgent = agent + 1
                if gameState.getNumAgents() == nextAgent: #daca cumva s a atins numarul maxim de fantome atunci agentul devine iar pac-man si crestem adancimea arborelui
                    nextAgent = 0
                    depth = depth + 1

                return min(minMax(gameState.generateSuccessor(agent, newState), nextAgent, depth) for newState in gameState.getLegalActions(agent))
            else:
                # daca suntem la primul nivel din arbore adica la pac-man nodul ia valoarea maxima dupa apelul recursiv de aflare al valorilor de pe frunze
                return max(minMax(gameState.generateSuccessor(agent, newState), 1, depth) for newState in gameState.getLegalActions(agent))

        maxActions = -1
        action = Directions.WEST #initializam prima actiune
        
        for legalAction in gameState.getLegalActions(0): #parcurgem toate actiune legale ce le poate face pac-man 
            
            #noi vrem maximul pe starea finala deci reactualizam maximul daca starea curenta este mai mare
            utility = minMax( gameState.generateSuccessor(0, legalAction), 1, 0)
            if utility > maxActions:
                maxActions = utility
                action = legalAction
            if maxActions == -1:
                maxActions = utility
                action = legalAction

        return action #starea finala

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"

        #Algoritmul Alpha-Beta Pruning are la baza algoritmul Minimax insa este mult mai optimizat atat din punct al timpului cat si al complexitatii
        #Avem aceeasi pasi ca la Minimax doar ca aici parcurgem frunzele nodului respectiv si daca gasim o valoare care sa nu devina valoarea vruta ne oprim din parcurgere( prin comparatie cu alpha si beta)

        def maxValue(agent, depth, gameState, a, b):
            v = float("-inf")

            for successor in gameState.getLegalActions(agent):

                v = max(v, alphabetaprune(1, depth, gameState.generateSuccessor(agent, successor), a, b))
                if v > b:
                    return v
                a = max(a, v)
            return v

        
        def minValue(agent, depth, gameState, a, b):
            v = float("inf")

            # exact ca si la Minimax - verificam fantomele si reactualizam pac-man pe pozitia aferenta
            ghost = agent + 1
            if gameState.getNumAgents() == ghost: 
                ghost = 0
                depth = depth + 1

            for successor in gameState.getLegalActions(agent):

                v = min(v, alphabetaprune(ghost, depth, gameState.generateSuccessor(agent, successor), a, b))
                if v < a:
                    return v
                b = min(b, v)
            return v

        def alphabetaprune(agent, depth, game_state, a, b):

            if game_state.isLose():
                return self.evaluationFunction(game_state)

            if game_state.isWin():
                return self.evaluationFunction(game_state)

            if depth == self.depth:
                return self.evaluationFunction(game_state)

            if agent != 0:
                return minValue(agent, depth, game_state, a, b)
            else:
                return maxValue(agent, depth, game_state, a, b)      

        
        nodeValue = float("-inf")
        action = Directions.WEST
        alpha = float("-inf") #valoarea la cea mai buna alegere pe ramura de MAX
        beta = float("inf") #valoarea la cea mai buna alegere pe ramura de MIN

        for legalAction in gameState.getLegalActions(0):
            value = alphabetaprune(1, 0, gameState.generateSuccessor(0, legalAction), alpha, beta)

            #din nou vrem valoarea maxima la final deci comparam valoarea cu un maxim si reactualizam maximul
            if value > nodeValue:
                nodeValue = value
                action = legalAction
            if nodeValue > beta:
                return nodeValue
            alpha = max(alpha, nodeValue) # avem nevoie si de reactualizarea lui alpha la fiecare pas

        return action #starea finala

        #util.raiseNotDefined()

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"

        util.raiseNotDefined()

def betterEvaluationFunction(currentGameState: GameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

# Abbreviation
better = betterEvaluationFunction
